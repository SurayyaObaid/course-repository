<?php

include 'header.php';
include 'config.php';

$courses = "select * from course where status = 0";
$executec  = mysqli_query($mysqli, $courses);

$sessions = "select * from session";
$executes  = mysqli_query($mysqli, $sessions);

$batchesb = "select * from batch";
$executeb  = mysqli_query($mysqli, $batchesb);

$teacher = "select * from teacher";
$executet  = mysqli_query($mysqli, $teacher);
$fetchtitle = "";
$fetchcode="";
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Course Enrolment</title>
  <link rel="stylesheet" type="text/css" href="css/register.css">
</head>
<body style="margin-top:20px;">

  <div class="header w-50 bg-dark justify-content-center" style="margin-top: 100px;">
    <h2 >Course Enrollment</h2>
  </div>
   
  <form method="post" class="w-50 justify-content-center" enctype="multipart/form-data" action="TeacherCourse.php">
    <center>
    
    <div class="input-group">
      <label>Select Course Title</label><br><br>
      <select class="bg-light border border-dark col-lg-11 rounded" required="required" name="selected-course">
         <option></option>
        <?php 
        if ($executec) {
          while ($row = mysqli_fetch_array($executec)) {
            $courseTitle = $row['course_Title'];
            echo "<option>$courseTitle<br></option>";
          }
        }
         ?>
       
      </select>
    </div>
  
    <div class="input-group">
      <label>Select Batch</label>
     </div>
      <select class="bg-light border border-dark col-lg-11 rounded" required="required" name="selected-batch">
         <option></option>
        <?php 
        if ($executeb) {
          while ($row = mysqli_fetch_array($executeb)) {
            $program = $row['degree_Program'];
            $year = $row['year'];
            $batch = $program . " " . $year;
            echo "<option>$batch<br></option>";
          }
        }
         ?>
       
      </select>
      
    </div><br>
    <div class="input-group">
      <label>Select Teacher</label><br><br>
      <center>
      <select class="bg-light border border-dark col-lg-11 rounded" required="required" name="selected-teacher">
         <option></option>
        <?php 
        if ($executec) {
          while ($row = mysqli_fetch_array($executet)) {
            $teacher = $row['user_Name'];
            echo "<option>$teacher<br></option>";
          }
        }
         ?>
       
      </select>
       <div class="input-group justify-content-center pt-4">
       <input type="submit" class="btn bg-dark text-light" style="padding: 10px; height: 40px; width: 300px; margin-left: -40px;" name="enrol_course" value="Assign Course" >
           

 <?php
if(isset($_POST['enrol_course'])){
    $scourse = $_POST['selected-course'];
    $steacher = $_POST['selected-teacher'];
    $sbatch = $_POST['selected-batch'];
    //echo "string". $scourse . $steacher . $sbatch;
    if ($scourse == "" || $steacher == "" || $sbatch =="") {
      echo "Incomplete information!";
    }
    $fetchFaculty = "select * from teacher where user_Name ='".$steacher."'";
    $executeft  = mysqli_query($mysqli, $fetchFaculty);
    if ($executeft) {
       
          while ($row = mysqli_fetch_array($executeft)) {
            $teacherID = $row['teacher_ID'];
            //echo "teacher ID: ".$teacherID;
          }}
    
    $fetchCourse = "select * from course where course_Title = '".$scourse."'";
    $executefc  = mysqli_query($mysqli, $fetchCourse);
   if ($executefc) { 
        
          while ($row = mysqli_fetch_array($executefc)) {
            $courseID = $row['Course_ID'];
            $fetchcode = $row['course_Code'];
            $fetchtitle = $row['course_Title'];
            //echo "course ID: ".$courseID;
          }}
    $fetchBatch = "select * from batch where year = '".$year."' && degree_Program = '".$program."'";
   $executefb  = mysqli_query($mysqli, $fetchBatch);
    if ($executefb) {
          while ($row = mysqli_fetch_array($executefb)) {
            $batchID = $row['Batch_ID'];
            //echo "batch ID: ".$batchID;
          }}
  $insert = "insert into `teacher-course` ( `teacher_ID`, `course_ID`, `batch`, `session_ID`) VALUES ('$teacherID', '$courseID', '$batchID', '6')";
$execute  = mysqli_query($mysqli, $insert);
$updatecourse = "update course set status = 1 where course_ID = '".$courseID."'";
$executeuc = mysqli_query($mysqli, $updatecourse);
$folder_name = $fetchtitle;
            if (!file_exists($output_dir.$folder_name))/* Check folder exists or not */
      {
        @mkdir($output_dir.$folder_name, 0777);/* Create folder by using mkdir function */
              echo "Folder Created";/* Success Message */
      }
    
    }



 ?>
 <a class="btn btn-dark text-light bg-dark" style="height: 40px; width: 300px;" href="view-assigned-course.php?course_Code=<?php echo $fetchcode; ?>">Edit Assigned Course</a>
      </div>  </center>